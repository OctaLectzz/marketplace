import{f as a,c as e}from"./index.30dd2348.js";const s=a("div",{class:"q-space"});var p=e({name:"QSpace",setup(){return()=>s}});export{p as Q};
