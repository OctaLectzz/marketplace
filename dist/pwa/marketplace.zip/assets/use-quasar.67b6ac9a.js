import{i as a,ah as r}from"./index.30dd2348.js";function u(){return a(r)}export{u};
