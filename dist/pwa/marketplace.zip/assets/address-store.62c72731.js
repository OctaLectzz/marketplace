import{ai as r}from"./index.30dd2348.js";import{server as e}from"./axios.66ae61ea.js";const t=r("address",{actions:{async all(){return await e.get("api/address")}}});export{t as u};
