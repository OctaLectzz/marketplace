import{f as a,c as e}from"./index.9abba36d.js";const s=a("div",{class:"q-space"});var p=e({name:"QSpace",setup(){return()=>s}});export{p as Q};
