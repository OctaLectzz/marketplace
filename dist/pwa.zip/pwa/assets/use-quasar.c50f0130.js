import{i as a,ah as r}from"./index.9abba36d.js";function u(){return a(r)}export{u};
