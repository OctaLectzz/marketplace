import{ai as r}from"./index.9abba36d.js";import{server as e}from"./axios.58437fad.js";const t=r("address",{actions:{async all(){return await e.get("api/address")}}});export{t as u};
